# AberturaLab Web — protótipo para Android

Esta versão troca a interface Streamlit por uma página estática que abre no navegador Android. O tabuleiro e a lógica de partida rodam no navegador; a análise Stockfish também é local, via WebAssembly.

## Estado deste protótipo

Incluído:
- tabuleiro interativo com lances legais;
- carregar posição FEN;
- desfazer, reiniciar e virar o tabuleiro;
- análise de posição usando Stockfish em Web Worker;
- importar PGN de arquivo ou texto;
- navegar pelos lances da partida;
- mostrar tags de abertura/ECO quando presentes no PGN.

Ainda não incluído nesta primeira base:
- importação automática de todo o histórico da conta Chess.com;
- banco ECO completo independente das tags do PGN;
- análise em lote de todas as partidas;
- estatísticas confiáveis por abertura/cor;
- detecção automática de respostas perigosas e exercícios personalizados.
Essas funções devem ser adicionadas em etapas, depois de validar a engine no Android.

## Arquivos Stockfish necessários

A pasta do site precisa conter os dois arquivos compatíveis da versão Stockfish.js Lite single-threaded:
- `stockfish-19-lite-single.js`
- `stockfish-19-lite-single.wasm`

Eles precisam ficar ao lado de `index.html`, porque o navegador carrega o worker por caminho relativo. O projeto não inclui esses arquivos grandes de engine no ZIP. Use os arquivos oficiais do pacote Stockfish.js e confira os termos de licença (GPLv3) antes de redistribuir.

## Como testar

1. Coloque os dois arquivos Stockfish acima na mesma pasta de `index.html`.
2. Publique a pasta em uma hospedagem estática HTTPS que sirva arquivos `.js` e `.wasm` com MIME types corretos.
3. Abra o endereço no Chrome do Android.
4. Toque em **Analisar posição**. Na primeira vez, o navegador baixa a engine; depois poderá reutilizar o cache.
5. Para análise de partidas, exporte PGN do Chess.com e importe aqui.

Observações:
- O site precisa ser servido por HTTP/HTTPS; abrir o arquivo `index.html` diretamente (`file://`) pode impedir o Worker de funcionar.
- O download inicial e a biblioteca de tabuleiro usam internet; a busca do Stockfish, depois que a engine é carregada, acontece no dispositivo.
- A análise profunda pode aquecer o aparelho e gastar bateria; comece com profundidade 8–10.
- Este protótipo não foi testado no dispositivo do usuário. Teste a engine antes de considerar a versão pronta.
