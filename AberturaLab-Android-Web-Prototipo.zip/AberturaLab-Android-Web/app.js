(() => {
  const $ = id => document.getElementById(id);
  const PIECES = { K:'♔', Q:'♕', R:'♖', B:'♗', N:'♘', P:'♙', k:'♚', q:'♛', r:'♜', b:'♝', n:'♞', p:'♟' };
  let game = new Chess();
  let engine = null, engineReady = false, flipped = false, selected = null, legalTargets = [], currentFen = game.fen(), loadedHeaders = {};
  const historyStack = [];

  function renderBoard() {
    const root = $('board'); root.className = 'board'; root.innerHTML = '';
    const ranks = flipped ? [1,2,3,4,5,6,7,8] : [8,7,6,5,4,3,2,1];
    const files = flipped ? ['h','g','f','e','d','c','b','a'] : ['a','b','c','d','e','f','g','h'];
    const board = game.board();
    ranks.forEach(rank => files.forEach(file => {
      const sq = file + rank, f = file.charCodeAt(0)-97, r = rank-1, piece = board[r][f];
      const btn = document.createElement('button'); btn.className = 'sq ' + ((f+r)%2===0?'light':'dark'); btn.dataset.square = sq;
      if (selected === sq) btn.classList.add('selected'); if (legalTargets.includes(sq)) btn.classList.add('target');
      if (piece) { const span = document.createElement('span'); span.textContent = PIECES[piece.color==='w'?piece.type.toUpperCase():piece.type]; span.className = piece.color==='w'?'piece-white':'piece-black'; btn.appendChild(span); }
      if ((!flipped && f===0) || (flipped && f===7)) { const c=document.createElement('span'); c.className='coord'; c.textContent=rank; btn.appendChild(c); }
      if ((!flipped && rank===1) || (flipped && rank===8)) { const c=document.createElement('span'); c.className='coord'; c.style.left='auto'; c.style.right='3px'; c.textContent=file; btn.appendChild(c); }
      btn.addEventListener('click',()=>onSquare(sq)); root.appendChild(btn);
    }));
    $('fenInput').value = game.fen();
  }
  function onSquare(sq) {
    const piece = game.get(sq);
    if (selected && legalTargets.includes(sq)) {
      historyStack.push(game.fen());
      const move = game.move({from:selected,to:sq,promotion:'q'});
      selected=null; legalTargets=[]; renderBoard(); if(move) $('analysisResult').innerHTML=`Jogada: <strong>${move.san}</strong>. É a vez das ${game.turn()==='w'?'brancas':'negras'}.`; return;
    }
    if(piece && piece.color===game.turn()) { selected=sq; legalTargets=game.moves({square:sq,verbose:true}).map(m=>m.to); }
    else { selected=null; legalTargets=[]; }
    renderBoard();
  }
  function setStatus(text,ready=false){$('engineStatus').textContent=text;$('engineStatus').classList.toggle('ready',ready)}
  function startEngine(){
    if(engine) return;
    try {
      engine = new Worker('./stockfish-19-lite-single.js');
      engine.onmessage = ev => {
        const line = String(ev.data || '');
        if(line === 'uciok') { engine.postMessage('isready'); }
        if(line === 'readyok') { engineReady=true; setStatus('Stockfish pronto',true); }
        if(line.startsWith('info ') && line.includes(' score ')) {
          const depth=(line.match(/\bdepth (\d+)/)||[])[1]; const cp=(line.match(/\bscore cp (-?\d+)/)||[])[1]; const mate=(line.match(/\bscore mate (-?\d+)/)||[])[1]; const pv=(line.match(/\bpv (.+)$/)||[])[1];
          if(depth && (cp || mate)) { const score=mate?`mate em ${mate}`:`${(Number(cp)/100).toFixed(2)} peões`; $('analysisResult').innerHTML=`<div><strong>Profundidade ${depth}</strong> · avaliação ${score}</div><div style="margin-top:7px">Linha principal: <strong>${pv||'calculando...'}</strong></div><div class="muted" style="margin-top:7px">Avaliação apresentada do ponto de vista das brancas.</div>`; }
        }
        if(line.startsWith('bestmove ')) { const best=line.split(/\s+/)[1]; $('analysisResult').innerHTML += `<div style="margin-top:8px">Melhor lance encontrado: <strong>${best}</strong></div>`; }
      };
      engine.onerror = () => { setStatus('Engine não carregou'); $('analysisResult').textContent='Não foi possível carregar Stockfish. Confira se stockfish-19-lite-single.js e stockfish-19-lite-single.wasm estão na mesma pasta deste site.'; };
      engine.postMessage('uci'); setStatus('Carregando Stockfish…');
    } catch(e) { setStatus('Engine indisponível'); $('analysisResult').textContent='Não foi possível iniciar a engine neste navegador.'; }
  }
  function analyze(){
    startEngine();
    if(!engine) return;
    if(!engineReady){$('analysisResult').textContent='Aguarde a engine terminar de carregar e toque em Analisar posição novamente.';return;}
    const depth=Number($('depth').value); $('analysisResult').innerHTML='<span class="muted">Stockfish está calculando no celular…</span>';
    engine.postMessage('stop'); engine.postMessage('ucinewgame'); engine.postMessage('position fen '+game.fen()); engine.postMessage('go depth '+depth);
  }
  function loadFen(){const fen=$('fenInput').value.trim();const candidate=new Chess();if(candidate.load(fen)){game=candidate;selected=null;legalTargets=[];historyStack.length=0;renderBoard();$('analysisResult').textContent='Posição FEN carregada.';}else{$('analysisResult').textContent='FEN inválida. Confira o texto e tente novamente.';}}
  function loadPgn(text){
    const clean=text.trim(); if(!clean){$('pgnSummary').textContent='Cole um PGN ou escolha um arquivo.';return;}
    const candidate=new Chess(); let ok=false;
    try { ok=candidate.load_pgn(clean,{sloppy:true}); } catch(e) { ok=false; }
    if(!ok){$('pgnSummary').textContent='Não consegui ler esse PGN. Tente exportar novamente em formato PGN padrão.';return;}
    game=candidate; selected=null;legalTargets=[];historyStack.length=0; currentFen=game.fen();
    // Reconstruct mainline for navigation using a fresh game and captured SAN history.
    const hist=game.history(); const navGame=new Chess(); const positions=[navGame.fen()];
    hist.forEach(m=>{navGame.move(m);positions.push(navGame.fen());});
    const headers={}; const headerText=clean.split(/\r?\n/).filter(l=>/^\s*\[[A-Za-z0-9_]+\s+"/.test(l));
    headerText.forEach(l=>{const m=l.match(/^\s*\[([^\s]+)\s+"(.*)"\]\s*$/);if(m)headers[m[1]]=m[2];}); loadedHeaders=headers;
    renderBoard(); $('pgnSummary').innerHTML=`Partida carregada: <strong>${headers.White||'Brancas'}</strong> × <strong>${headers.Black||'Negras'}</strong> · ${hist.length} lances · resultado ${headers.Result||'*'}.`;
    $('gameMoves').innerHTML='';
    hist.forEach((m,i)=>{const b=document.createElement('button');b.className='move-chip';b.textContent=(i%2===0?`${Math.floor(i/2)+1}. `:'')+m;b.addEventListener('click',()=>{const g=new Chess();for(let j=0;j<=i;j++)g.move(hist[j]);game=g;selected=null;legalTargets=[];renderBoard();document.querySelectorAll('.move-chip').forEach(x=>x.classList.remove('active'));b.classList.add('active');});$('gameMoves').appendChild(b);});
    const opening=headers.Opening||headers.ECO||'Nome não informado no PGN';
    $('openingInfo').innerHTML=`<div><strong>${opening}</strong></div><div style="margin-top:7px">ECO: ${headers.ECO||'não informado'} · Jogou de brancas: ${headers.White||'desconhecido'} · Jogou de negras: ${headers.Black||'desconhecido'}</div><div class="muted" style="margin-top:7px">Esta versão usa as etiquetas presentes no PGN; não inventa um nome quando a fonte não o informa.</div>`;
  }
  $('undoBtn').addEventListener('click',()=>{const fen=historyStack.pop();if(fen){game.load(fen);selected=null;legalTargets=[];renderBoard();}});
  $('resetBtn').addEventListener('click',()=>{game.reset();selected=null;legalTargets=[];historyStack.length=0;renderBoard();$('analysisResult').textContent='Tabuleiro reiniciado.';});
  $('flipBtn').addEventListener('click',()=>{flipped=!flipped;renderBoard();});
  $('loadFenBtn').addEventListener('click',loadFen); $('analyzeBtn').addEventListener('click',analyze);
  $('depth').addEventListener('input',()=>{$('depthLabel').textContent=$('depth').value;});
  $('pgnFile').addEventListener('change',async e=>{const f=e.target.files&&e.target.files[0];if(f){const text=await f.text();$('pgnText').value=text;loadPgn(text);}});
  $('loadPgnBtn').addEventListener('click',()=>loadPgn($('pgnText').value));
  renderBoard();
})();
